
const sHydration = document.getElementById('sHydration');
const sNutrition = document.getElementById('sNutrition');
const sCleanliness = document.getElementById('sCleanliness');
const sXP = document.getElementById('sXP');
const sLevel = document.getElementById('sLevel');
const moodBadge = document.getElementById('moodBadge');
const pestsLayer = document.getElementById('pests');
const stage = document.getElementById('stage');

let stats = {
  hydration: 70,
  nutrition: 40,
  cleanliness: 80,
  xp: 0,
  level: 1,
  pests: 0,
  mood: 80
};

function clamp(v, min=0, max=100){ return Math.max(min, Math.min(max, v)); }
function vibrate(ms){ if (navigator.vibrate) navigator.vibrate(ms); }

function updateUI(){
  sHydration.textContent = stats.hydration.toFixed(0);
  sNutrition.textContent = stats.nutrition.toFixed(0);
  sCleanliness.textContent = stats.cleanliness.toFixed(0);
  sXP.textContent = stats.xp.toFixed(0);
  sLevel.textContent = stats.level.toFixed(0);
  moodBadge.textContent = `Nálada: ${stats.mood.toFixed(0)}%`;
}

function computeMood(){
  const tComfort = 90; // simple const for demo
  stats.mood = clamp(0.35*stats.hydration + 0.25*60 + 0.2*stats.nutrition + 0.1*stats.cleanliness + 0.1*tComfort);
}

function spawnPest(){
  if (stats.cleanliness >= 55) return;
  if (Math.random() > 0.02) return;
  const pest = document.createElement('div');
  pest.className = 'pest';
  pest.style.left = Math.random() * (stage.clientWidth - 14) + 'px';
  pest.style.top  = Math.random() * (stage.clientHeight - 14) + 'px';
  pest.addEventListener('click', () => {
    pest.remove();
    stats.pests = Math.max(0, stats.pests - 1);
    stats.xp += 2;
    vibrate(12);
  });
  pestsLayer.appendChild(pest);
  stats.pests += 1;
}

function degrade(){
  stats.hydration = clamp(stats.hydration - 0.05);
  stats.nutrition = clamp(stats.nutrition - 0.02);
  stats.cleanliness = clamp(stats.cleanliness - 0.03);
  if (stats.xp >= stats.level * 20){
    stats.level += 1;
  }
}

function loop(){
  degrade();
  computeMood();
  spawnPest();
  updateUI();
}

setInterval(loop, 500);
updateUI();

document.getElementById('btnWater').addEventListener('click', () => {
  stats.hydration = clamp(stats.hydration + 20);
  stats.xp += 3;
  vibrate(15);
});

document.getElementById('btnFertil').addEventListener('click', () => {
  stats.nutrition = clamp(stats.nutrition + 15);
  stats.xp += 5;
  vibrate(15);
});

document.getElementById('btnSpray').addEventListener('click', () => {
  stats.cleanliness = clamp(stats.cleanliness + 10);
  stats.pests = Math.max(0, stats.pests - 2);
  pestsLayer.innerHTML = '';
  stats.xp += 4;
  vibrate(10);
});
