
# Greenbuddy – Starter Pack (PWA)
Toto je jednoduchá verzia „živej rastlinky“ ako webová appka, ktorú vieš nahrať na internet bez programovania.

## Ako spustiť (najjednoduchšie)
1. Choď na **vercel.com** a prihlás sa (stačí e-mail).
2. Hore klikni **Add New… → Project → Import** a vyber **Upload** (nahraj tento ZIP).
3. Keď deploy skončí, dostaneš link (napr. `greenbuddy.vercel.app`). Otvor ho v mobile a v menu prehliadača daj **Add to Home Screen** (Pridať na plochu).

Hotovo – máš appku s ikonou na ploche. Funguje aj offline vďaka service workeru.

## Čo je v balíku
- `index.html` – stránka s rastlinkou a tlačidlami (Zaliať, Hnojiť, Postrek)
- `script.js` – jednoduchá herná logika (XP, úbytok parametrov, škodcovia)
- `style.css` – dizajn
- `assets/monstera.svg` – dočasná SVG animácia listu (kýve sa ako vietor)
- `manifest.json`, `service-worker.js`, `icons/` – aby to fungovalo ako PWA (appka na ploche)
- `data/*.json` – ukážka súborov, ktoré neskôr nahradíme Google Sheets

## Čo bude ďalej
- Nahradíme SVG animáciu za **Rive (.riv)**, ktorá bude vyzerať „živšie“ (žmurkanie, emócie, plynulé pohyby).
- Pridáme **mini-admin cez Google Sheets** – budeš vedieť upraviť texty a odmeny bez kódu.
- Potom doplníme **Plánovač** a **Knižnicu rastlín**.

Ak niečo nebude jasné, stačí otvoriť `index.html` – všetko je pripravené tak, aby to hneď fungovalo.
